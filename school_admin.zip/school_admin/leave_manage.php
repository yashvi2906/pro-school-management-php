<?php
session_start();
if(!isset($_SESSION['currentuser']))
{
  echo"<script>window.location.href='login.php';</script>";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        Leave
    </title>
    <link rel="stylesheet" href="prileave.css?v<?php echo time(); ?>"/>

    <link
      href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"
      rel="stylesheet"
      />
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link
href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
rel="stylesheet"
/>
    <link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
rel="stylesheet"
/>
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
  
  </head>
  <body>

 


    <!-- ----header---- -->
    
   
    <div class="sidenav">
    <div class="top">
            <div class="logo">
              <!-- <span style="height:50px; width: 40px;"><img src="schoollogo.jpg" alt="logo"></span> -->
 
  
              <h2>AD<span class="danger">MIN</span></h2>
            </div>
            <!-- <div class="close" id="close-btn">
              <span class="material-icons-sharp">close</span>
            </div> -->
          </div>
    
          <div class="sidebar">
            <a href="princi.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
              <h3>Dashboard</h3>
            </a>
    
            <a href="studentinfo.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
              <h3>Student</h3>
            </a>
    
            <a href="tchrinfo.php" class="active">
              <span class="material-icons-sharp">group </span>
              <h3>Teachers</h3>
            </a>
    
            <a href="adviewatt.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
              <h3>Attendance</h3>
            </a>
    
            <!-- <a href="#" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a>
     -->
            <a href="notice.php" class="active">
              <span class="material-icons-sharp">event_note </span>
              <h3>Notice</h3>
            </a>
            <a href="leave_manage.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span><h3>Leave</h3>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
              <h3>Logout</h3>
            </a>
          </div>
      </div>
      <!-- ------------------------------end of sidebar---------------------- -->
<!-- --------------------------end of aside------------------------------------------------------------- -->

<div class="main">
    <h2 style="margin-top: 20px;">Leave <span style="color: #097997;">Applications</span></h2>
    <!-- <div class="flex-container">
        <div>Leave Applications</div>
        <div></div>
        <div>3</div>  
      </div> -->

      
      <?php

      include 'connection.php';
       $q="select * from leavetbl";
      $res=mysqli_query($conn,$q);


      foreach($res as $r)
      {
          $sr=$r['sr_no'];
            $tn=$r['tchrnm'];
          $lv=$r['leave_type'];
          $fr=$r['fr_dt'];
          $to=$r['to_dt'];
          $det=$r['detail'];
      ?>
      <div class="stutable">  

<table>
    <tbody>

<tr>
<td>
        <h2><?php echo $lv;?> <br>
        <label style="font-size: 15px;">  <?php echo $tn;?></label> </h2><label style="margin-right: 15px;  margin-left: 850px; font-size: 13px;"><?php echo $fr;?></label>to<label style="margin-left: 15px; font-size: 13px;"><?php echo $to;?></label>
    <br>
    <label style="margin-right:33%;"><?php echo $det;?></label>

    <a> <form method='POST' action='princi_leave.php'>
    <input type='text' name='sr_no' value='<?php echo $sr; ?>' hidden>
    <input type='text' name='tchrnm' value='<?php echo $tn; ?>' hidden>
    <input type='text' name='leave_type' value='<?php echo $lv; ?>' hidden>
    <input type='text' name='fr_dt' value='<?php echo $fr; ?>' hidden>
    <input type='text' name='to_dt' value='<?php echo $to; ?>' hidden>
    <input type='text' name='detail' value='<?php echo $det; ?>' hidden>
    <button  name="confirm" style="font-size: 13px; color:white;   background-color:#219dbe; width: 60px;
    height: 30px;
      border-radius: 20px;
      cursor: pointer;">Confirm
    </button>  
    <button  name="reject" style="font-size:13px;width: 60px; height: 30px; color: white;   background-color: #219dbe;
    border-radius: 20px;
    cursor: pointer;">    Reject</button></form></a>
    </td>

</tr>
</tbody>
                </table>
      </div>
<?php
    }
      ?>

    </div>
  </body>
</html>