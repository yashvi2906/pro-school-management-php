-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2023 at 10:55 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `leavetbl`
--

DROP TABLE IF EXISTS `leavetbl`;
CREATE TABLE `leavetbl` (
  `sr_no` int(11) NOT NULL,
  `leave_type` varchar(50) NOT NULL,
  `fr_dt` date NOT NULL,
  `to_dt` date NOT NULL,
  `detail` varchar(10000) NOT NULL,
  `lv_st` varchar(255) NOT NULL,
  `tchrnm` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `leavetbl`
--

INSERT INTO `leavetbl` (`sr_no`, `leave_type`, `fr_dt`, `to_dt`, `detail`, `lv_st`, `tchrnm`) VALUES
(1, 'casual', '2023-03-09', '2023-03-11', 'sxdcfgvb', 'confirmed from admin', 'navin'),
(5, 'sick leave', '2023-03-10', '2023-03-14', 'feaver', 'rejected from admin', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `leavetbl`
--
ALTER TABLE `leavetbl`
  ADD PRIMARY KEY (`sr_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `leavetbl`
--
ALTER TABLE `leavetbl`
  MODIFY `sr_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;


--
-- Metadata
--
USE `phpmyadmin`;

--
-- Metadata for table leavetbl
--
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
