
-- --------------------------------------------------------

--
-- Table structure for table `tchratt`
--

DROP TABLE IF EXISTS `tchratt`;
CREATE TABLE `tchratt` (
  `No` int(2) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `1` date NOT NULL,
  `2` date NOT NULL,
  `3` date NOT NULL,
  `4` date NOT NULL,
  `5` date NOT NULL,
  `6` date NOT NULL,
  `7` date NOT NULL,
  `8` date NOT NULL,
  `9` date NOT NULL,
  `10` date NOT NULL,
  `11` date NOT NULL,
  `12` date NOT NULL,
  `13` date NOT NULL,
  `14` date NOT NULL,
  `15` date NOT NULL,
  `16` date NOT NULL,
  `17` date NOT NULL,
  `18` date NOT NULL,
  `19` date NOT NULL,
  `20` date NOT NULL,
  `21` date NOT NULL,
  `22` date NOT NULL,
  `23` date NOT NULL,
  `24` date NOT NULL,
  `25` date NOT NULL,
  `26` date NOT NULL,
  `27` date NOT NULL,
  `28` date NOT NULL,
  `29` date NOT NULL,
  `30` date NOT NULL,
  `31` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
