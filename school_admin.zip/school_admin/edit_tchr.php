<?php
session_start();
if(!isset($_SESSION['currentuser']))
{
  echo"<script>window.location.href='login.php';</script>";
}

?>
<?php
include('connection.php');

$num=$_GET['num'];
$nm=$_GET['nm'];
$qlf=$_GET['qlf'];
$ph=$_GET['ph']; 
$em=$_GET['em'];
$gndr=$_GET['gen'];
$wex=$_GET['workex'];
$dob=$_GET['dob'];
$jn_dt=$_GET['jn_dt'];
$blg=$_GET['blg'];
$cst=$_GET['caste'];
$add=$_GET['adrs'];



?>

<!DOCTYPE html>
<html lang="en">
<head>
<!-- <meta http-equiv="refresh" content="10; url=tchrinfo.php"> -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Form</title>
    <link rel="stylesheet" href="tchrcss.css?v<?php echo time(); ?>">
    <link rel="stylesheet" href="leave.css"> 


    <link
    href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"
    rel="stylesheet"
    />
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />

<link
href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
rel="stylesheet"
/>
  <link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
rel="stylesheet"
/>
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
</head>
<body>
<?php
include 'connection.php';
// error_reporting(0);

$sql = " SELECT * FROM tchrinfo ORDER BY num ASC";
$result = mysqli_query($conn,$sql);
?>



<div class="sidenav">
    <div class="top">
            <div class="logo">
              <!-- <span style="height:50px; width: 40px;"><img src="schoollogo.jpg" alt="logo"></span> -->
 
  
              <h2>AD<span class="danger">MIN</span></h2>
            </div>
            <!-- <div class="close" id="close-btn">
              <span class="material-icons-sharp">close</span>
            </div> -->
          </div>
    
          <div class="sidebar">
            <a href="princi.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
              <h3>Dashboard</h3>
            </a>
    
            <a href="studentinfo.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
              <h3>Student</h3>
            </a>
    
            <a href="tchrinfo.php" class="active">
              <span class="material-icons-sharp">group </span>
              <h3>Teachers</h3>
            </a>
    
            <a href="adviewatt.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
              <h3>Attendance</h3>
            </a>
    
            <!-- <a href="#" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a>
     -->
            <a href="notice.php" class="active">
              <span class="material-icons-sharp">event_note </span>
              <h3>Notice</h3>
            </a>
            <a href="leave_manage.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span><h3>Leave</h3>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
              <h3>Logout</h3>
            </a>
          </div>
      </div>
        <!-- ==========================main==================== -->
        
    
        <div class="main">
        <h1  style="margin-top: 20px;" >Teacher <span style="color: #097997;"> Form</span><a href="dataT.php" class="hstr" 
   >
   <span class="material-symbols-sharp">
demography
</span>
            <h3 class="hstr">Data</h3>
          </a></h1>                <form method="POST">
                    <div class="row">
                  <div class="col-25">
                    <label for="num">No</label>
                    <input type="text" id="num" name="num" value="<?php echo $num ?>" pattern="[0-9]{1/2}" placeholder="00"  required>
            
            
                  </div>
                        <div class="col-25">
                            <label for="first-name">Name</label>
                            <input type="text" id="first-name" name="Name" value= "<?php echo $nm ?>"style="text-transform:capitalize" required>
                        </div>
                       
                    </div>
                
                <div class="row">
                  <div class="col-25">
                    <label for="admission-date">Joining Date</label>
                    <!-- <input type="date" id="admission-date" name="Admission_date"  required value=""> -->

                    <?php
  $timestamp = strtotime($jn_dt);
  $date = date( "Y-m-d", $timestamp );
           ?>

           <input type="date" name="JoiningD" value="<?php echo $date; ?>">

          
                </div>
                  <div class="col-25">
                    <label for="Qualification">Qualification</label>
                    <input type="text" id="Qualification" name="Qualification" value="<?php echo $qlf ?>" required>
                </div>                                                           
                
                        <div class="col-25">
                          <label for="WorkEp">Work Experience</label>
                          <input type="text" id="WorkEp" name="WorkEp" value="<?php echo $wex ?>" placeholder="Total year in no:00" pattern="[0-9]{2}" required>
                      </div>
                </div>
                    <div class="row">
                        <div class="col-25">
                            <label for="gender">Gender</label>
                            <select id="gender" name="Gender"  value= "<?php echo $gndr ?>" required>
                            <option value="<?php echo $gndr; ?>" selected><?php echo $gndr; ?></option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="col-25">
                          <label for="birthdate">Birthdate</label>
                          <?php
  $timestamp = strtotime($dob);
  $date = date( "Y-m-d", $timestamp );
           ?>

           <input type="date" name="DOB" value="<?php echo $date; ?>">

                      </div>
                      
                  <div class="col-25">
                    <label for="bloodgrp">Blood Group</label>
                    <select id="bloodgrp" name="BloodG"  value="<?php echo $blg?>"  required>
                    <option value="<?php echo $blg; ?>" selected><?php echo $blg; ?></option>
                     <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        </select>
                  </div>
                </div>
                
                <div class="row">
                  <!-- <div class="col-25">
                            <label for="nationality">Nationality</label>
                            <input type="text" id="nationality" name="Nationality" style="text-transform:capitalize" required>
                        </div>
                        <div class="col-25">
                            <label for="religion">Religion</label>
                            <input type="text" id="religion" name="Religion" style="text-transform:capitalize" required>
                        </div> -->
                  <div class="col-25">
                            <label for="caste">Caste</label>
                            <select id="caste" name="Caste" value="<?php echo "$cst"?>" required>
                            <option value="<?php echo $cst; ?>" selected><?php echo $cst; ?></option>
                                <option value="General">General</option>
                                <option value="OBC">OBC</option>
                                <option value="SC">SC</option>
                                <option value="ST">ST</option>
                            </select>
                        </div>
                </div>
                <div class="row">
                    <div class="col-25">
                      <label for="cast">Phone no.</label>
              <input type="tel" id="phone" name="Phone" value= "<?php echo $ph?>" pattern="[0-9]{10}" required>
                      </div>
                      <div class="col-25">
                        <label for="email">Email:</label>
                          <input type="email" id="email" name="Email" value= "<?php echo $em ?>" required>
                          
                      </div>
                  </div>
                  <div class="row">
                  
                  <div class="col-25 addrs" >
                    <label for="address">Address:</label>
                    <textarea  id="address" name="Address" required><?php echo $add; ?></textarea>
                </div>
                </div>
                <div class="row">
                    <div class="col-50">
                    <input type="submit" value="update" name="update" onclick="togglePopup()">
                    </div>
                  </div>
                </div>
              
                </form>


      <?php while($rows=$result->fetch_assoc()) { ?>
            
          <!-- <tr>
              <td><?php echo $rows['num'];?></td>
              <td><?php echo $rows['Name'];?></td>
              <td><?php echo $rows['Qualification'];?></td>
              <td><?php echo $rows['Phone'];?></td>
               <td><?php echo $rows['Email'];?></td>
               <td><?php echo $rows['Gender'];?></td>
               <td><?php echo $rows['WorkEp'];?></td>
               <td><?php echo $rows['DOB'];?></td>
               <td><?php echo $rows['JoiningD'];?></td>
               <td><?php echo $rows['BloodG'];?></td>
               <td><?php echo $rows['Caste'];?></td> 
              <td><?php echo $rows['Address'];?></td> -->

              <!-- <form method="POST"> -->
<!--              
<td><a href="edit_tchr.php?num=<?php echo $rows['num']; ?>&nm=<?php echo $rows['Name'];?>&qlf=<?php echo $rows['Qualification'];?>&ph=<?php echo $rows['Phone'];?>&em=<?php echo $rows['Email'];?>& gen=<?php echo $rows['Gender'];?>&workex=<?php echo $rows['WorkEp'];?> &dob=<?php echo $rows['DOB'];?>&jn_dt=<?php echo $rows['JoiningD'];?> &blg=<?php echo $rows['BloodG'];?> &caste=<?php echo $rows['Caste'];?>&adrs=<?php echo $rows['Address'];?>" class="mr-25" data-toggle="tooltip" data-original-title="Edit"> <i class="material-symbols-sharp">app_registration</i></a></td>

<td> 

<td>
<a href="tchrinfo.php?delete=<?php echo $rows['num'];?>" data-toggle="tooltip" name="delete" data-original-title="Delete" onclick="return confirm('Do you really want to delete?');"> <i class="material-symbols-sharp" style="color:red">delete_forever</i> </a>

              </td>
           </tr>
              </form> -->

<?php
include 'connection.php';

              if(isset($_GET['delete']))
             {
              $dlt=$_GET['delete'];
              $sqldlt = "DELETE FROM tchrinfo WHERE num='$dlt'";
              
              $rdlt = mysqli_query($conn, $sqldlt);
              // header("localtion");
              // header("Location: ".$_SERVER['PHP_SELF']);
              }
            ?>   

          <?php
              }
           ?> 
      <!-- </tbody>
            </table>
            <a href="#">Show All</a>
          </div>  -->


 <!-- =======================================Popup form============== -->
<!-- <div class="popup" id="popup">
  <div class="popup-content">
    <span class="close-btn" onclick="togglePopup()">&times;</span>
    <h2 style="color: #097997;">Success!</h2>
    <p>Your submission was successful.</p>
  </div>
</div> -->



             <script>
   
//  function togglePopup() {
//   document.getElementById("popup").classList.toggle("popup-active");
//  }
            </script> 
            
      <?php
        include 'connection.php';
        if(isset($_POST['update']))
        {
        //   header('localtion:tchrinfo.php');
            $num=$_POST['num'];
            $nm=$_POST['Name'];
            $dob=$_POST['DOB'];
            $qlf=$_POST['Qualification'];

            $gndr=$_POST['Gender'];
            $jn_dt=$_POST['JoiningD'];
            $workex=$_POST['WorkEp'];
            $Bl_g=$_POST['BloodG'];
            // $nation=$_POST['Nationality'];
            // $reli=$_POST['Religion'];
            $caste=$_POST['Caste'];
            $ph=$_POST['Phone'];
            $email=$_POST['Email'];
            $add=$_POST['Address'];
            
            $sqlup="UPDATE `tchrinfo`  SET  `Name`='$nm', `DOB`='$dob',`Qualification`='$qlf', `Gender`='$gndr',`JoiningD`='$jn_dt', `WorkEp`='$workex',`Caste`='$caste',  `Phone`='$ph', `Email`='$email', `BloodG`='$Bl_g',`Address`='$add' WHERE num=$num;";
            

            // $sql = "INSERT INTO tchrinfo(`num`,`Name`,`DOB`,`Qualification`,`Gender`,`JoiningD`,`WorkEp`,`BloodG`,`Nationality`,`Religion`,`Caste`,`Phone`,`Email`,`Address`) VALUES($num,'$nm','$dob','$qlf','$gndr','$jn_dt', $workex,'$Bl_g','$nation','$reli','$caste',$ph,'$email','$add');";
            $result = mysqli_query($conn,$sqlup);
            if($result){
              echo "success";
            }
            else{
              echo mysqli_error($conn);
            }
        }
        ?>

    </body>
</html>