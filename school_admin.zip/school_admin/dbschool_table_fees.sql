
-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

DROP TABLE IF EXISTS `fees`;
CREATE TABLE `fees` (
  `Receiptno` int(10) NOT NULL,
  `Date` date NOT NULL DEFAULT current_timestamp(),
  `UID` int(20) NOT NULL,
  `FName` varchar(20) NOT NULL,
  `LName` varchar(20) NOT NULL,
  `Class` int(1) NOT NULL,
  `Rollno` int(2) NOT NULL,
  `total_amount` int(4) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `Addmission_fee` int(4) NOT NULL,
  `Sem_fee` int(4) NOT NULL,
  `Ed_fee` int(4) NOT NULL,
  `Late_fee` int(4) NOT NULL,
  `In_words` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
