
--
-- Indexes for dumped tables
--

--
-- Indexes for table `fees`
--
ALTER TABLE `fees`
  ADD PRIMARY KEY (`UID`);

--
-- Indexes for table `stdatt1`
--
ALTER TABLE `stdatt1`
  ADD PRIMARY KEY (`Rollno`);

--
-- Indexes for table `stdinfo`
--
ALTER TABLE `stdinfo`
  ADD PRIMARY KEY (`UID`);

--
-- Indexes for table `tchratt`
--
ALTER TABLE `tchratt`
  ADD PRIMARY KEY (`No`);
