<?php
$server = "localhost";
$username = "root";
$password = "";
$db = "school";

$conn = mysqli_connect($server, $username, $password, $db);
if($conn->connect_error)
{
 echo "connection failed";
}

// session_start();
// $s=$_SESSION['id'];

if(isset($_POST['done'])){
$m=$_GET['month'];
$y=$_GET['year'];
$c=$_GET['sd'];

$q= "SELECT * FROM `stdatt1` WHERE `Month`='$m', `Year`='$y', `Standard`=$c;";
$result = mysqli_query($conn,$q);
}
?>
<html>
    <body>
<div>
                <form action="tadviewatt.php" method="POST">
                <div class="stable"> 
                <!-- <h1 style="margin-top: 20px;" >Teacher <span style="color: #097997;"> Form</span><a href="tchrinfo.php" class="hstr" 
   >
   <span class="material-symbols-sharp">
description
</span>
            <h3 class="hstr">Form</h3>
          </a></h1> -->
                <div style="overflow-x:auto;text-align:left;">

<table style="width: 120%; margin-left:0; box-shadow: none;">
              <thead>
                <tbody>
                <th>UID</th>
                    <th>Standard</th>
                    <th>Name</th>
                    <th>1</th>
                    <th>2</th>
                    <th>3</th>
                    <th>4</th>
                    <th>5</th>
                    <th>6</th>
                    <th>7</th>
                    <th>8</th>
                    <th>9</th>
                    <th>10</th>
                    <th>11</th>
                    <th>12</th>
                    <th>13</th>
                    <th>14</th>
                    <th>15</th>
                    <th>16</th>
                    <th>17</th>
                    <th>18</th>
                    <th>19</th>
                    <th>20</th>
                    <th>21</th>
                    <th>22</th>
                    <th>23</th>
                    <th>24</th>
                    <th>25</th>
                    <th>26</th>
                    <th>27</th>
                    <th>28</th>
                    <th>29</th>
                    <th>30</th>
                    <th>31</th>
                   

                <?php   
              while($rows=$result->fetch_assoc())

              // $res=mysqli_query($conn, "SELECT COUNT(`1`) FROM `stdatt1`");
              // $data=mysqli_fetch_assoc($res);
              // echo $data['Total'];
                {
                 
                ?>
                <tr>
                   
                <td><?php echo $rows['UID'];?></td>
              <td><?php echo $rows['Standard'];?></td>
              <td><?php echo $rows['FName'];?></td>
              <td><?php echo $rows['1'];?></td>
              <td><?php echo $rows['2'];?></td>
              <td><?php echo $rows['3'];?></td>
              <td><?php echo $rows['4'];?></td>
              <td><?php echo $rows['5'];?></td>
              <td><?php echo $rows['6'];?></td>
              <td><?php echo $rows['7'];?></td>
              <td><?php echo $rows['8'];?></td>
              <td><?php echo $rows['9'];?></td>
              <td><?php echo $rows['10'];?></td>
              <td><?php echo $rows['11'];?></td>
              <td><?php echo $rows['12'];?></td>
              <td><?php echo $rows['13'];?></td>
              <td><?php echo $rows['14'];?></td>
              <td><?php echo $rows['15'];?></td>
              <td><?php echo $rows['16'];?></td>
              <td><?php echo $rows['17'];?></td>
              <td><?php echo $rows['18'];?></td>
              <td><?php echo $rows['19'];?></td>
              <td><?php echo $rows['20'];?></td>
              <td><?php echo $rows['21'];?></td>
              <td><?php echo $rows['22'];?></td>
              <td><?php echo $rows['23'];?></td>
              <td><?php echo $rows['24'];?></td>
               <td><?php echo $rows['25'];?></td>
               <td><?php echo $rows['26'];?></td>
               <td><?php echo $rows['27'];?></td>
               <td><?php echo $rows['28'];?></td>
               <td><?php echo $rows['29'];?></td>
               <td><?php echo $rows['30'];?></td>
               <td><?php echo $rows['31'];?></td> 
                
                </tr>
                <?php
              }
          ?>
            </tbody>
            </thead>
            </table>
            </div>
        </form>
</div>
        </body>
</html>