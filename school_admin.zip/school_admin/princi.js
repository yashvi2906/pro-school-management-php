const sideMenu = document.querySelector("aside");
const menuBtn = document.querySelector("#menu-btn");
const colseBtn = document.querySelector("#close-btn");

menuBtn.addEventListener('click', () => {
    sideMenu.style.display = 'block';
})

colseBtn.addEventListener('click', () => {
    sideMenu.style.display = 'none';
})