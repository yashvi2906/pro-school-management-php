
-- --------------------------------------------------------

--
-- Table structure for table `stdatt1`
--

DROP TABLE IF EXISTS `stdatt1`;
CREATE TABLE `stdatt1` (
  `UID` int(20) NOT NULL,
  `Rollno` int(2) NOT NULL,
  `Month` int(2) NOT NULL,
  `Year` year(2) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `1` varchar(2) NOT NULL,
  `2` varchar(2) NOT NULL,
  `3` varchar(2) NOT NULL,
  `4` varchar(2) NOT NULL,
  `5` varchar(2) NOT NULL,
  `6` varchar(2) NOT NULL,
  `7` varchar(2) NOT NULL,
  `8` varchar(2) NOT NULL,
  `9` varchar(2) NOT NULL,
  `10` varchar(2) NOT NULL,
  `11` varchar(2) NOT NULL,
  `12` varchar(2) NOT NULL,
  `13` varchar(2) NOT NULL,
  `14` varchar(2) NOT NULL,
  `15` varchar(2) NOT NULL,
  `16` varchar(2) NOT NULL,
  `17` varchar(2) NOT NULL,
  `18` varchar(2) NOT NULL,
  `19` varchar(2) NOT NULL,
  `20` varchar(2) NOT NULL,
  `21` varchar(2) NOT NULL,
  `22` varchar(2) NOT NULL,
  `23` varchar(2) NOT NULL,
  `24` varchar(2) NOT NULL,
  `25` varchar(2) NOT NULL,
  `26` varchar(2) NOT NULL,
  `27` varchar(2) NOT NULL,
  `28` varchar(2) NOT NULL,
  `29` varchar(2) NOT NULL,
  `30` varchar(2) NOT NULL,
  `31` varchar(2) NOT NULL,
  `Total` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
