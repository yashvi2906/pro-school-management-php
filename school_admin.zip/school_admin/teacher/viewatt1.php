<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>View Attendance</title>
  <link rel="stylesheet" href="viewatt1.css?v<?php echo time(); ?>">
  <link
    href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"
    rel="stylesheet"
    /> 
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />

<link
href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
rel="stylesheet"
/> 
  <link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
rel="stylesheet"
/>
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 

</head>
<body>

<div class="sidenav">
    <div class="top">
            <div class="logo">
              <!-- <span style="height:50px; width: 40px;"><img src="schoollogo.jpg" alt="logo"></span> -->

  
              <h2>AD<span class="danger">MIN</span></h2>
            </div>

          </div>
    
          <div class="sidebar">
            
            <a href="tadmin.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
              <h3>Dashboard</h3>
            </a>
    
            <a href="tadsdata.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
              <h3>Student</h3>
            </a>
    
            <a href="tadattendance.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
              <h3>Attendance</h3>
            </a>
    
            <!-- <a href="#" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a>
    -->
            <a href="leave.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span><h3>Leave</h3>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
              <h3>Logout</h3>
            </a>
          </div>
      </div>
<!-- =======================responsive sidebar================== -->


<!-- =======================main========================== -->
<div class="main">
<div class="stable">  
              <h1 style="margin-top:20px;" >Atten<span style="color: #097997;">dance</span>

          </a></h1>  

          <form action="viewatt1.php" method="POST">
<!-- 
          <select required name="sd" class="form-control mb-3" style="color:black; background-color:white; width:130px; height:30px; border-radius: 10px; margin-top: 20px; margin-left: 8px; text-align:center;
            "
            >
                            <option value="" style="display: none;" style="margin-right:10px;">  Select Class</option>
                            <option value="1" style="color:black; ">1</option>
                            <option value="2" style="color:black;">2</option>
                            <option value="3" style="color:black;">3</option>
                            <option value="4" style="color:black;">4</option>
                            <option value="5" style="color:black;">5</option>
                            <option value="6" style="color:black;">6</option>
                            <option value="7" style="color:black;">7</option>
                            <option value="8" style="color:black;">8</option>
  
                  </select> -->
    <span style="display: none;">
        <label for="day">Day:</label>
        <select name="day" id="day"></select>
    </span>
    <span>
        <select input type="month" name="month" id="month" aria-placeholder="Select Month" style="color:black; background-color:white; width:130px; height:30px; border-radius: 10px; margin-top: 20px; margin-left: 8px; text-align:center; "></select>
    </span>
    <span>
        
        <select input type="Year" name="year"  id="year" style="color:black; background-color:white; width:130px; height:30px; border-radius: 10px; margin-top: 20px; margin-left: 8px; text-align:center;">Year:</select>
    </span>

    <button name="done" style="margin-left: 8px; background-color:#097997; color:
    white; border-radius:20px; height
    :30px; width:55px; cursor:pointer;">done</button>
</form>

<?php
 include 'connection.php';
include 'picker.html';
error_reporting(0);

$s=$_SESSION['id'];



if(isset($_POST['done'])){
    @$m=$_POST['month'];
    @$y=$_POST['year'];
    @$c=$_POST['sd'];

    
    if($m=="January")
    {
      $mn=1;
    }
    elseif($m=="February")
    {
      $mn=2;
    }
    elseif($m=="March")
    {
      $mn=3;
    }
    elseif($m=="April")
    {
      $mn=4;
    }
    elseif($m=="May")
    {
      $mn=5;
    }
    elseif($m=="June")
    {
      $mn=6;
    }
    elseif($m=="July")
    {
      $mn=7;
    }
    elseif($m=="August")
    {
      $mn=8;
    }
    elseif($m=="Sepetmber")
    {
      $mn=9;
    }
    elseif($m=="October")
    {
      $mn=10;
    }
    elseif($m=="November")
    {
      $mn=11;
    }
    elseif($m=="December")
    {
      $mn=12;
    }
    
// echo $mn;
// echo $y;
// echo $c;

    
   
    $q="SELECT * FROM `stdatt1` WHERE `Month`=$mn AND `Year`=$y AND `standard`=$s;";
    // $q= "SELECT * FROM `stdatt1` WHERE `Month`=$mn AND `Year`=$y AND `standard`=$c;";
    $result = mysqli_query($conn,$q);
    
    
    if($result){
        echo "<div>
    <form method='POST'>
    <div class='stable'> 
            
    <div style='overflow-x:auto;text-align:left;'>

        <table style='width: 120%; margin-left:0; box-shadow: none;'>
          <thead>
            <tbody>
            <th>UID</th>
                <th>Standard</th>
                <th>Name</th>
                <th>1</th>
                <th>2</th>
                <th>3</th>
                <th>4</th>
                <th>5</th>
                <th>6</th>
                <th>7</th>
                <th>8</th>
                <th>9</th>
                <th>10</th>
                <th>11</th>
                <th>12</th>
                <th>13</th>
                <th>14</th>
                <th>15</th>
                <th>16</th>
                <th>17</th>
                <th>18</th>
                <th>19</th>
                <th>20</th>
                <th>21</th>
                <th>22</th>
                <th>23</th>
                <th>24</th>
                <th>25</th>
                <th>26</th>
                <th>27</th>
                <th>28</th>
                <th>29</th>
                <th>30</th>
                <th>31</th>"; }
    }

?>

    <?php   

  while($rows=$result->fetch_assoc())

    {
    
    ?>
    <tr>
       
    <td><?php echo $rows['UID'];?></td>
  <td><?php echo $rows['Standard'];?></td>
  <td><?php echo $rows['FName'];?></td>
  <td><?php echo $rows['1'];?></td>
  <td><?php echo $rows['2'];?></td>
  <td><?php echo $rows['3'];?></td>
  <td><?php echo $rows['4'];?></td>
  <td><?php echo $rows['5'];?></td>
  <td><?php echo $rows['6'];?></td>
  <td><?php echo $rows['7'];?></td>
  <td><?php echo $rows['8'];?></td>
  <td><?php echo $rows['9'];?></td>
  <td><?php echo $rows['10'];?></td>
  <td><?php echo $rows['11'];?></td>
  <td><?php echo $rows['12'];?></td>
  <td><?php echo $rows['13'];?></td>
  <td><?php echo $rows['14'];?></td>
  <td><?php echo $rows['15'];?></td>
  <td><?php echo $rows['16'];?></td>
  <td><?php echo $rows['17'];?></td>
  <td><?php echo $rows['18'];?></td>
  <td><?php echo $rows['19'];?></td>
  <td><?php echo $rows['20'];?></td>
  <td><?php echo $rows['21'];?></td>
  <td><?php echo $rows['22'];?></td>
  <td><?php echo $rows['23'];?></td>
  <td><?php echo $rows['24'];?></td>
   <td><?php echo $rows['25'];?></td>
   <td><?php echo $rows['26'];?></td>
   <td><?php echo $rows['27'];?></td>
   <td><?php echo $rows['28'];?></td>
   <td><?php echo $rows['29'];?></td>
   <td><?php echo $rows['30'];?></td>
   <td><?php echo $rows['31'];?></td> 
    
    </tr>
    <?php
  }
?>
</tbody>
</thead>
</table>
</div>


<script>
    //Create references to the dropdown's
const yearSelect = document.getElementById("year");
const monthSelect = document.getElementById("month");
const daySelect = document.getElementById("day");

const months = ['January', 'February', 'March', 'April', 
'May', 'June', 'July', 'August', 'September', 'October',
'November', 'December'];

//Months are always the same
(function populateMonths(){
    for(let i = 0; i < months.length; i++){
        const option = document.createElement('option');
        option.textContent = months[i];
        monthSelect.appendChild(option);
    }
    monthSelect.value = "January";
})();

let previousDay;

function populateDays(month){
    //Delete all of the children of the day dropdown
    //if they do exist
    while(daySelect.firstChild){
        daySelect.removeChild(daySelect.firstChild);
    }
    //Holds the number of days in the month
    let dayNum;
    //Get the current year
    let year = yearSelect.value;

    if(month === 'January' || month === 'March' || 
    month === 'May' || month === 'July' || month === 'August' 
    || month === 'October' || month === 'December') {
        dayNum = 31;
    } else if(month === 'April' || month === 'June' 
    || month === 'September' || month === 'November') {
        dayNum = 30;
    }else{
        //Check for a leap year
        if(new Date(year, 1, 29).getMonth() === 1){
            dayNum = 29;
        }else{
            dayNum = 28;
        }
    }
    //Insert the correct days into the day <select>
    for(let i = 1; i <= dayNum; i++){
        const option = document.createElement("option");
        option.textContent = i;
        daySelect.appendChild(option);
    }
    if(previousDay){
        daySelect.value = previousDay;
        if(daySelect.value === ""){
            daySelect.value = previousDay - 1;
        }
        if(daySelect.value === ""){
            daySelect.value = previousDay - 2;
        }
        if(daySelect.value === ""){
            daySelect.value = previousDay - 3;
        }
    }
}

function populateYears(){
    //Get the current year as a number
    let year = new Date().getFullYear();
    //Make the previous 100 years be an option
    for(let i = 0; i < 101; i++){
        const option = document.createElement("option");
        option.textContent = year - i;
        yearSelect.appendChild(option);
    }
}

populateDays(monthSelect.value);
populateYears();

yearSelect.onchange = function() {
    populateDays(monthSelect.value);
}
monthSelect.onchange = function() {
    populateDays(monthSelect.value);
}
daySelect.onchange = function() {
    previousDay = daySelect.value;
}
</script>

    </body>
    
</html>
