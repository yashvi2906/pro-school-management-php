<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Attendence</title>
  <link rel="stylesheet" href="attendence.css?v<?php echo time(); ?>">
 <link
    href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"
    rel="stylesheet"
    /> 
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />

<link
href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
rel="stylesheet"
/> 
  <link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
rel="stylesheet"
/>
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<!-- ============bootstrap=================== -->

</head>
<body>



<div class="sidenav">
        <div class="top">
            <div class="logo">
              <!-- <span style="height:50px; width: 40px;"><img src="schoollogo.jpg" alt="logo"></span> -->
              <h2>AD<span class="danger">MIN</span></h2>
            </div>
            <!-- <div class="close" id="close-btn">
              <span class="material-icons-sharp">close</span>
            </div> -->
          </div>
    
          <div class="sidebar">
            <a href="tadmin.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
              <h3>Dashboard</h3>
            </a>
    
            <a href="tadsdata.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
              <h3>Student</h3>
            </a>
    
            <!-- <a href="tchrinfo.php" class="active">
              <span class="material-icons-sharp">group </span>
              <h3>Teachers</h3>
            </a>
     -->
            <a href="tadattendance.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
              <h3>Attendance</h3>
            </a>
    
            <!-- <a href="fees.php" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a> -->

            <a href="leave.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span><h3>Leave</h3>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
              <h3>Logout</h3>
            </a>
          </div>
      </div>
<!-- ======================================end of sidebar=========================================== -->
<div class="topnav">
  <a href="tadmin.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
            </a>
    
            <a href="tadsdata.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
            </a>
    
            <!-- <a href="tchrinfo.php" class="active">
              <span class="material-icons-sharp">group </span>
              <h3>Teachers</h3>
            </a>
     -->
            <a href="attendance.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
            </a>
    
            <!-- <a href="fees.php" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a> -->

            <a href="leave.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
            </a>
</div>
<!-- =======================responsive sidebar================== -->
<div class="main">
<h1  style="margin-top: 20px;" >Student<span style="color: #097997;"> Attendance </span><a href="viewatt1.php" class="hstr" 
   >
   <span class="material-symbols-sharp">
fact_check
</span>
            <h3 class="hstr">Data</h3>
          </a></h1>
          <div class="stable">  
            
            <table>
              <thead>
                        <tr>
                
                  <th>Roll No</th>
                  <th> Name</th>
                 
          <th>Present</th>
          <th>Absent</th>

          <!-- <th>Absent</th> -->
                </tr> <thead>
                    <tbody>



<?php
include 'connection.php';


$s=$_SESSION['id'];
$sql="SELECT * FROM `stdinfo` WHERE `standard`=$s;";
$result = mysqli_query($conn,$sql);

?>
                    <?php
              
              while($rows=$result->fetch_assoc())
              {
                $uid=$rows['UID'];
          ?>
                    <tr> 
              
              <td><?php echo $rows['UID'];?></td>
              <td><?php echo $rows['FName'];?></td>
           
              <td><form method="POST"><input type="text" name="id" value="<?php echo $uid; ?>" hidden>
              <button name= "P" vaue="P" style="color:green; cursor: pointer;" type="submit">P</button></td>
              <td>
<button  name= "A" value="A" style="color:red; 
 " type="submit">A</button></td></form></thead>





<?php

$total = substr_count(implode($rows), 'p');
// Update the 'total' column with the count
 $uid = $rows['UID']; // assuming the table has a primary key column named 'id'
 $sqlupdt="UPDATE stdatt1 SET Total = $total WHERE UID = $uid";
$resupdt=mysqli_query($conn,$sqlupdt);

//$insrttot = "INSERT INTO stdatt1 (`Total`) values ($total);"

?>
              <?php
              }
          ?> 

                    </tbody>
                <tbody>
            
                    </table>
                    </div> 
</div>        <?php

   
            // echo date('j');
            $d=Date('j');
            if(isset($_POST['P']))
            {
                $id=$_POST['id'];
                $today = date("Y-m-d");
                // $date = '2023-04-01'; // the input date
    
                // create a DateTime object from the input date
                $datetime = new DateTime($today);
                
                // extract the day, month, and year from the DateTime object
                $day = $datetime->format('d');
                $month = $datetime->format('m');
                $year = $datetime->format('Y');
                $sql1="UPDATE `stdatt1` SET `$d`='P', `Year`='$year', `Month`='$month' WHERE `UID`=$id";
                if(!mysqli_query($conn,$sql1))
                {
                    echo "error";
                }
            }
            elseif(isset($_POST['A']))
            {
                $id=$_POST['id'];
                $today = date("Y-m-d");
                // $date = '2023-04-01'; // the input date
    
                // create a DateTime object from the input date
                $datetime = new DateTime($today);
                
                // extract the day, month, and year from the DateTime object
                $day = $datetime->format('d');
                $month = $datetime->format('m');
                $year = $datetime->format('Y');
                $sql1="UPDATE `stdatt1` SET `$d`='A', `Year`='$year', `Month`='$month' WHERE `UID`=$id";
                if(!mysqli_query($conn,$sql1))
                {
                    echo "error";
                }
            }
            ?> 
                
                <script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>
</body>
</html>
