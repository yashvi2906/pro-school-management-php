<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="leave.css?v<?php echo time(); ?>"/>


    <title>Leave</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />
    
    <link
      href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"
      rel="stylesheet"
      />
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link
href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
rel="stylesheet"
/>
    <link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
rel="stylesheet"
/>
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
  
  </head>
  <body>

  <?php
include 'connection.php';

$sql = " SELECT * FROM stdinfo ORDER BY standard DESC";
$result = mysqli_query($conn,$sql);

?>
<?php
include 'connection.php';
// error_reporting(0);
$sql1="SELECT * FROM notice";
$noti=mysqli_query($conn,$sql1);
?>


    <!-- ----header---- -->
    
   
    <div class="sidenav">
    <div class="top">
            <div class="logo">
              <!-- <span style="height:50px; width: 40px;"><img src="schoollogo.jpg" alt="logo"></span> -->

  
              <h2>AD<span class="danger">MIN</span></h2>
            </div>

          </div>
    
          <div class="sidebar">
            
            <a href="tadmin.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
              <h3>Dashboard</h3>
            </a>
    
            <a href="tadsdata.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
              <h3>Student</h3>
            </a>
    
            <a href="tadattendance.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
              <h3>Attendance</h3>
            </a>
    
            <!-- <a href="#" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a>
    -->
            <a href="leave.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span><h3>Leave</h3>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
              <h3>Logout</h3>
            </a>
          </div>
      </div>   <!-- ------------------------------end of sidebar---------------------- -->
      <div class="topnav">
  <a href="tadmin.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
            </a>
    
            <a href="tadsdata.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
            </a>
    
            <!-- <a href="tchrinfo.php" class="active">
              <span class="material-icons-sharp">group </span>
              <h3>Teachers</h3>
            </a>
     -->
            <a href="attendance.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
            </a>
    
            <!-- <a href="fees.php" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a> -->

            <a href="leave.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
            </a>
</div>
<!-- =======================responsive sidebar================== -->

      <div class="main">

        <form method="POST">
        <a href="history.php" class="hstr">
              <span class="material-icons-sharp">history
 </span>
              <h3 class="hstr">History</h3>
            </a>
         

            <h1>Teacher <span style="color: #097997;">  Name</span> </h1>
            <div class=input>
          <input type="text" id="fname" name="tchrnm" placeholder="teacher name">
      
          <h1>Apply <span style="color: #097997;"> for </span> Leave</h1>
          <input type="text" id="fname" name="leave_type" placeholder="leave type...." >
          </div>
             <h2 style="margin-top: 0px;">From <span style="color: #097997;"> Date</span></h2>
          <input type="date" name="fr_dt" ><h2 style="margin-top: 30px;">To<span style="color: #097997;"> Date</span></h2>
          <input type="date" name="to_dt" ><br><br>
          <!-- <h2>Det<span style="color: #097997;">ail</span></h2> -->
         <div class="textarea"> <textarea id="detail" name="detail" placeholder="Description...."   required></textarea>
         <br>
         <input  type="submit" name="submit" value="Send"></div>
        </form>
      </div>


    <?php
    include 'connection.php';
   
    if(isset($_POST['submit'])){
        $tn=$_POST['tchrnm'];
$lv = $_POST['leave_type'];
$fr=$_POST['fr_dt'];
$to=$_POST['to_dt'];
$det=$_POST['detail'];

$sql="INSERT INTO `leavetbl` (`leave_type`,`fr_dt`,`to_dt`,`detail`,`tchrnm`) VALUES ('$lv','$fr','$to','$det','$tn');";
$result=mysqli_query($conn, $sql);

}

    
    ?>
</body>
</html>
