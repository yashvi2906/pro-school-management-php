<html>
	<head>

	<link rel="stylesheet" href="dash.css?v<?php echo time(); ?>"/>
    <link rel="stylesheet" href="leave.css?v<?php echo time(); ?>"/>
  
	</head>
    <body>
    <table>

  <section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				
			</div>
			<div class="row">
				<div class="col-md-12">
					<h4 class="text-center mb-4">Pending Booking Requests</h4>
					<div class="table-wrap">
						<table class="table">
					    <thead class="thead-primary">
					      <tr>
                          <!-- <th>sr no</th> -->
						  <th>Teacher's Name</th>
					        <th>leave type</th>
					        <th>from</th>
					        <th>to</th>
					        <th>detail</th>
					        <th>action</th>
                            </tr>
					    </thead>
					    <tbody>

					    	<?php

					    		include 'connection.php';

								$q="select * from leavetbl";
								$res=mysqli_query($conn,$q);


								foreach($res as $r)
								{
                                    $sr=$r['sr_no'];
									$tn=$r['tchrnm'];
								    $lv=$r['leave_type'];
								    $fr=$r['fr_dt'];
								    $to=$r['to_dt'];
								    $det=$r['detail'];
								   
								    echo "<tr>
                                    
									<td>".$tn."</td>
								    <td>".$lv."</td>
								    <td>".$fr."</td>
								    <td>".$to."</td>
								    <td>".$det."</td>
								    
								    <td><form method='POST'>
                                    <input type='text' value='$sr' name='sr_no' hidden>
									<input type='text' value='$tn' name='tchrnm' hidden>
									<input type='text' value='$lv' name='leave_type' hidden>
								    <input type='text' value='$fr' name='fr_dt' hidden>
								    <input type='text' value='$to' name='to_dt' hidden>
								    <input type='text' value='$det' name='detail' hidden>
								   
								    <input type='submit' value='confirm leave request' name='confirm' class='btn btn-primary'>
                                    </form>
								<td>
								<form method='post'>
                                <input type='text' value='$sr' name='sr_no' hidden>
								<input type='text' value='$tn' name='tchrnm' hidden>
									<input type='text' value='$lv' name='leave_type' hidden>
								    <input type='text' value='$fr' name='fr_dt' hidden>
								    <input type='text' value='$to' name='to_dt' hidden>
								    <input type='text' value='$det' name='detail' hidden>
								   
								<input type='submit' value='reject leave request' name='reject' class='btn btn-primary'></form></td>
								   </tr>";   
								}
        if(isset($_POST['confirm']))
        {
            $sr=$_POST['sr_no'];
			$tn=$_POST['tchrnm'];
			$lv=$_POST['leave_type'];
			$fr=$_POST['fr_dt'];
            $to=$_POST['to_dt'];
            $det=$_POST['detail'];

            $sql1="UPDATE `leavetbl` SET `lv_st`='confirmed from admin' WHERE sr_no=$sr;";
            if($result=mysqli_query($conn, $sql1))
            {
                echo "done";
				echo "<script>window.location.href='leave_manage.php';</script>";
            }
            else
            {
                echo mysqli_error($conn);
            }
        }
        if(isset($_POST['reject']))
        {
            $sr=$_POST['sr_no'];
			$tn=$_POST['tchrnm'];
			$lv=$_POST['leave_type'];
			$fr=$_POST['fr_dt'];
            $to=$_POST['to_dt'];
            $det=$_POST['detail'];

            $sql2="UPDATE `leavetbl` SET `lv_st`='rejected from admin' WHERE sr_no=$sr;";
            if($result=mysqli_query($conn, $sql2))
            {
                echo "done";
				// header("location: leave_manage.php");
				echo "<script>window.location.href='leave_manage.php';</script>";
            }
            else

            {
                echo mysqli_error($conn);
            }
        }

        ?>

</tbody>
				</table>
					</div>
				</div>
			</div>
		</div>
	</section>
</body>
</html>